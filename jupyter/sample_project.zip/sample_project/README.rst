TODO: Add README for the Acr Weights Calculator project.
